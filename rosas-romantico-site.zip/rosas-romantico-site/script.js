// Stars generation and small texts
const starTexts = [
  'Uma lembrança tua em cada brilho.',
  'Sussurro suave: bom dia, meu amor.',
  'Onde você passa, o céu sorri.',
  'Um abraço que atravessa a noite.',
  'Seu riso, farol da minha madrugada.',
  'Silêncio doce — teu nome na brisa.',
  'Promessa de um amanhã com você.',
  'Luz pequena que guia meus passos.',
  'Teu olhar faz as estrelas corarem.',
  'Noite adocicada, teu perfume no ar.'
];

function createStars() {
  const stars = document.getElementById('stars');
  const list = document.getElementById('starsList');
  // create CSS stars as small divs with random positions
  for (let i=0;i<80;i++){
    const s = document.createElement('div');
    s.className = 'star-dot';
    const size = Math.random()*2 + 0.6;
    s.style.position='absolute';
    s.style.width = size+'px';
    s.style.height = size+'px';
    s.style.borderRadius='50%';
    s.style.left = (Math.random()*100)+'%';
    s.style.top = (Math.random()*100)+'%';
    s.style.background = 'radial-gradient(circle, rgba(255,255,255,1) 0%, rgba(255,255,255,0.6) 30%, rgba(255,255,255,0.0) 70%)';
    s.style.opacity = (Math.random()*0.6 + 0.4).toString();
    s.style.transform = 'translate3d(0,0,0)';
    s.style.pointerEvents='none';
    // twinkle
    const dur = Math.random()*6 + 3;
    s.style.animation = `twinkle ${dur}s infinite ease-in-out`;
    s.style.animationDelay = (Math.random()*-dur) + 's';
    stars.appendChild(s);
  }

  // populate small star texts
  for (let i=0;i<starTexts.length;i++){
    const item = document.createElement('div');
    item.className = 'star-item';
    item.textContent = '★ ' + starTexts[i];
    list.appendChild(item);
  }
}

// Create hearts with translations
const phrases = [
  {lang:'Português', text:'Eu te amo, Giovanna.'},
  {lang:'Inglês', text:'I love you, Giovanna.'},
  {lang:'Espanhol', text:'Te amo, Giovanna.'},
  {lang:'Francês', text:'Je t\'aime, Giovanna.'},
  {lang:'Italiano', text:'Ti amo, Giovanna.'},
  {lang:'Alemão', text:'Ich liebe dich, Giovanna.'},
  {lang:'Japonês', text:'愛してるよ, Giovanna (Aishiteru yo, Giovanna).'},
  {lang:'Chinês', text:'我爱你，Giovanna (Wǒ ài nǐ, Giovanna).'},
  {lang:'Russo', text:'Я люблю тебя, Giovanna.'},
  {lang:'Árabe', text:'أحبكِ يا Giovanna.'}
];

function createHearts() {
  const container = document.getElementById('heartsContainer');
  phrases.forEach((p, idx) => {
    const b = document.createElement('div');
    b.className = 'heart';
    b.innerHTML = '❤';
    b.title = p.lang;
    b.dataset.phrase = p.text;
    b.addEventListener('click', (e) => {
      playClick();
      showPhrase(p);
      b.classList.remove('animated');
      void b.offsetWidth;
      b.classList.add('animated');
    });
    container.appendChild(b);
  });
}

// Show phrase in the phrase box
function showPhrase(p) {
  const box = document.getElementById('phraseBox');
  box.innerHTML = `<strong>${p.lang}:</strong> ${p.text}`;
}

// Simple click sound using WebAudio API
let audioCtx;
function playClick(){
  try{
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const o = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    o.type = 'sine';
    o.frequency.value = 880; // high click
    g.gain.value = 0.0001;
    o.connect(g);
    g.connect(audioCtx.destination);
    const now = audioCtx.currentTime;
    g.gain.setValueAtTime(0.0001, now);
    g.gain.exponentialRampToValueAtTime(0.02, now + 0.004);
    g.gain.exponentialRampToValueAtTime(0.0001, now + 0.12);
    o.start(now);
    o.stop(now + 0.14);
  }catch(e){
    // audio failed (autoplay policy) - ignore
    console.warn('audio error', e);
  }
}

// tab switching
function setupTabs(){
  document.querySelectorAll('.tab-button').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-button').forEach(b=>b.classList.remove('active'));
      btn.classList.add('active');
      const tab = btn.dataset.tab;
      document.querySelectorAll('.tab-panel').forEach(p => p.classList.add('hidden'));
      document.getElementById(tab).classList.remove('hidden');
    });
  });
}

// CSS keyframes for twinkle (injected)
function injectTwinkleStyles(){
  const style = document.createElement('style');
  style.textContent = `@keyframes twinkle{0%{opacity:0.1}50%{opacity:1}100%{opacity:0.1}}`;
  document.head.appendChild(style);
}

// init
window.addEventListener('load', () => {
  injectTwinkleStyles();
  createStars();
  createHearts();
  setupTabs();
  // initial phrase
  showPhrase(phrases[0]);
});